﻿//-----------------------------------------------------------------------
// <copyright file="Copyright.cs" author="Michael Herndon">
//     Copyright (c) Company.  All rights reserved.
// </copyright>
//-----------------------------------------------------------------------

namespace Amplify.ActiveRecord
{
	using System;
	using System.Collections;
	using System.Collections.Generic;
	using System.ComponentModel;
	using System.Data;
	using System.Text;

	//using Amplify.ComponentModel;
	using Amplify.ActiveRecord.Data;

	public class Base<T> : UnitOfWork, IDataErrorInfo
		where T: Base<T>
	{

		//public const string all = "all";
		//public const string first = "first";
		//public const string conditions = "conditions";
		//public const string joins = "joins";
		//public const string limit = "limit";
		//public const string order = "order";
		//public const string having = "having";
		//public const string select = "select";
		//public const string distinct = "distinct";


		public static T New()
		{
			return Activator.CreateInstance<T>();
		}

		public static T New(IDictionary values)
		{
			T obj = New();
			obj.Merge(values);
			return obj;
		}

		//public static T Create()
		//{
		//    T obj = New();
		//    obj.Save();
		//    return obj;
		//}

		//public static T Create(IDictionary values)
		//{
		//    T obj = New(values);
		//    obj.Save();
		//    return obj;
		//}

		//public static object FindBySql(string sql)
		//{
		//    return null;
		//}


		//public static List<T> FindAll()
		//{
		//    return new List<T>();
		//}

		//public static T Find(object id)
		//{
		//    return null;
		//}

		//public static T FindOrCreate(object id)
		//{
		//    return null;
		//}

		//public static List<T> Find(string scope)
		//{

		//}

		//public static List<T> Find(string scope, object value)
		//{

		//}

		//public static List<T> Find(string scope, object value, object value)
		//{

		//}

		//public static List<T> Find(Selection selection)
		//{
		//    selection.Scope(Scope.All);
		//    return null;
		//}


		//public static T Load(IDataReader datareader) 
		//{
		//    T obj = New();
		//    if(datareader.Read())
		//    {
		//        for (int i = 0; i < datareader.FieldCount; i++)
		//        {
		//            string name = datareader.GetName(i);
		//            object value = datareader[i];
		//            if(value == DBNull)
		//                value = null;
		//            obj[name] = value;
		//        }
		//    }
		//    return obj;
		//}

		public Base()
		{
			this.Initialize();
		}

		internal protected Base(IDictionary values)
		{
			this.Initialize();
			this.Merge(values);
		}

		internal protected Base(object transferObject)
		{
			this.Initialize();
			if (transferObject is IDictionary)
				this.Merge((IDictionary)transferObject);
			if(transferObject is DecoratedInternalObject)
				this.Merge((DecoratedInternalObject)transferObject);
		}


		internal protected virtual void Initialize() 
		{

		}
		

		internal protected void Merge(IDictionary values) 
		{
			foreach (string key in values.Keys)
				this[key] = values[key];
		}


		internal protected void Merge(DecoratedInternalObject obj)
		{
			this.Merge(obj.Values);
		}


		#region IDataErrorInfo Members

		string IDataErrorInfo.Error
		{
			get { throw new NotImplementedException(); }
		}

		string IDataErrorInfo.this[string columnName]
		{
			get { throw new NotImplementedException(); }
		}

		#endregion

		#region IDataValidationInfo Members

		//IEnumerable<IValidationRule> IDataValidationInfo.this[string propertyName]
		//{
		//    get { throw new NotImplementedException(); }
		//}

		#endregion
	}
}
