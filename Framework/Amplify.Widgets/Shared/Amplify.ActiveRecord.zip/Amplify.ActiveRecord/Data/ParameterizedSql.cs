﻿//-----------------------------------------------------------------------
// <copyright file="Copyright.cs" author="Michael Herndon">
//     Copyright (c) Company.  All rights reserved.
// </copyright>
//-----------------------------------------------------------------------

namespace Amplify.ActiveRecord.Sql
{
	using System;
	using System.Collections.Generic;
	using System.Text;

	public class ParameterizedSql : Sql
	{
		private IDictionary<string, object> parameters;

		public ParameterizedSql() { }

		public ParameterizedSql(string sql) : base(sql) { }

		public ParameterizedSql(string sql, IDictionary<string, object> parameters)
			: base(sql)
		{
			this.parameters = parameters;
		}


	}
}
