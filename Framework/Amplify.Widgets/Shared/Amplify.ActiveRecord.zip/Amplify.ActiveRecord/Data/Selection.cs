﻿

namespace Amplify.ActiveRecord.Data
{
	using System;
	using System.Collections.Generic;
	using System.ComponentModel;
	using System.Data;
	using System.Text;

	


	public class Selection : QueryBase<Selection> 
	{
		public Selection()
		{
			this.Type = QueryType.Select;
		}
	}
}
