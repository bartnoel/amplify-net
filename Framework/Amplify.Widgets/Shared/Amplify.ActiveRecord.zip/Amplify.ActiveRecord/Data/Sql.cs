﻿//-----------------------------------------------------------------------
// <copyright file="Copyright.cs" author="Michael Herndon">
//     Copyright (c) Company.  All rights reserved.
// </copyright>
//-----------------------------------------------------------------------

namespace Amplify.ActiveRecord.Sql
{
	using System;
	using System.Collections.Generic;
	using System.Text;

	public class Sql 
	{
		private string sql = "";

		protected string Sql { get; set; }

		public Sql() {
			this.Sql = "";
		}

		public Sql(string sql)
		{
			this.Sql = sql;
		}

		public override string ToString()
		{
			return this.Sql;
		}
	}
}
