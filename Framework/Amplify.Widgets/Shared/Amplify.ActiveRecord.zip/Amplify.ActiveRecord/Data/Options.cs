﻿

namespace Amplify.ActiveRecord.Data
{
	using System;
	using System.Collections.Generic;
	using System.Data;
	using System.Linq;
	using System.Text;

	public class Options : IOptions 
	{
		public CommandType Type { get; set; }
		public object Conditions { get; set; }
		public string OrderBy { get; set; }
		public string GroupBy { get; set; }
		public string Having { get; set; }
		public int Limit { get; set; }
		public int Offset { get; set; }
		public IEnumerable<IDbDataParameter> Parameters { get; set; }


		

	}
}
