﻿//-----------------------------------------------------------------------
// <copyright file="Copyright.cs" author="Michael Herndon">
//     Copyright (c) Company.  All rights reserved.
// </copyright>
//-----------------------------------------------------------------------

namespace Amplify.ActiveRecord.Data
{
	using System;
	using System.Collections.Generic;
	using System.Data;
	using System.Text;

	using Amplify.Mixins.Sql;

	public class Condition
	{
		private string sqlOperator = "WHERE";
		private string condition = "";
		private string columnName = "";
		private object value;

		public Condition(string condition)
		{
			this.condition = condition;
		}

		public Condition(string condition, string sqlOperator)
		{
			this.condition = condition;
			this.sqlOperator = sqlOperator;
		}

		public Condition(string columnName, object value)
		{
			this.columnName = columnName;
			this.value = value;
		}


		public Condition(string columnName, object value, string sqlOperator):this(columnName, value)
		{
			this.sqlOperator = sqlOperator;
		}


		public override string ToString()
		{
			return base.ToString(false);
		}

		public virtual string ToString(bool useAdoParameters)
		{
			if (!string.IsNullOrEmpty(this.condition))
				return string.Format(" {0} {1}", this.sqlOperator, this.condition);
				
			if (useAdoParameters)
				return string.Format(" {0} {1} = {2}{1}", sqlOperator, columnName, Selection.ParameterPrefix);
			else
				return string.Format(" {0} {1} = '{2}'", sqlOperator, columnName, value.Sanitize());
		}
	}
}
