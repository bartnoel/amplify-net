﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Amplify.ActiveRecord.Data
{
	public class ColumnDefinition
	{
		public string Name { get; set; }
		public string Type { get; set; }
		public int Limit { get; set; }
		public int Precision { get; set; }
		public int Scale { get; set; }
		public object Default { get; set; }
		public bool IsNull { get; set; }

		protected virtual bool IncludeDefault
		{
			get { return true;  }
		}

		public string SqlType()
		{

		}

		public string ToSql()
		{

		}

		protected virtual string AddColumnOptions()
		{
			
       // sql << " DEFAULT #{quote(options[:default], options[:column])}" if options_include_default?(options)
       // sql << " NOT NULL" if options[:null] == false
    

			string options = "";
			options += (this.IncludeDefault) ? "" : string.Format(" DEFAULT {0}", ""); 
			options += (this.IsNull) ? "" : "NOT NULL ";
			return options;
		}

		protected IAdapter Adapter { get; set; }
		

	}
}
