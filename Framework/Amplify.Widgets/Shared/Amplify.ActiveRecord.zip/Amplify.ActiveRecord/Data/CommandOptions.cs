﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Amplify.ActiveRecord.Data
{
	public class CommandOptions : ICommandOptions 
	{

		#region ICommandOptions Members

		public string CommandText { get; set; }

		public Scope Scope { get; set; }

		public System.Data.CommandType CommandType { get; set; }

		public IEnumerable<System.Data.IDataParameter> Parameters { get; set; }

		#endregion
	}
}
