﻿

namespace Amplify.ActiveRecord.Data
{
	using System;
	using System.Collections.Generic;
	using System.Collections;
	using System.ComponentModel;
	using System.Text;
	using System.Text.RegularExpressions;

	public abstract class QueryBase<T> where T: QueryBase<T>
	{

		private Scope scope = Scope.All;
		private QueryType type = QueryType.Select;
		private List<string> fields = new List<string>();
		private Dictionary<string, object> values = new Dictionary<string, object>();
		private string databaseEntity = "";
		private string tableAlias = "";
		private List<Join> joins = new List<Join>();
		private Options options;
		

		//private List<string> includes = new List<string>();
		//private List<string> joins = new List<string>();
		
		
		
		
		//private static bool s_useAdoParameters = true;
		//private static string s_parameterPrefix = "@";
		//private static object s_lock = new object();

		public QueryBase()
		{
			this.Adapter = Cfg.DefaultAdapter;
			this.ParameterPrefix = this.Adapter.ParameterPrefix;
		}

		public string TableAlias
		{
			get {
				if (string.IsNullOrEmpty(this.tableAlias))
					this.tableAlias = this.DatabaseEntity[0].ToString().ToLower();
				return this.tableAlias;
			}
			set {
				this.tableAlias = value;
			}
		}

		public string DatabaseEntity { get; set; }

		public IAdapter Adapter { get; set; }

		public bool UseDataParameters { get; set; }

		public string ParameterPrefix { get; set; }

		protected QueryType Type { get; set; }

		public bool IsDistinct { get; set; }

		public virtual bool UseTableAlias
		{
			get 
			{
				return (this.joins.Count > 0);
			}
		}

		public T Of(IEnumerable<string> fields)
		{
			this.fields.AddRange(fields);
			return(T)this;
		}

		public T From(string databaseEntity)
		{
			this.databaseEntity = databaseEntity;
			return (T)this;
		}

		public T Where(string clause)
		{
			this.whereClause += string.Format("{0} {1} ", this.nextOperator, clause);
			return (T)this;
		}

		public T StartBlock
		{
			get
			{
				this.whereClause += string.Format("{0} (", this.nextOperator);
				return (T)this;
			}
		}

		public T EndBlock
		{
			get
			{
				this.whereClause += ") ";
				return (T)this;
			}
		}

		private string ReplaceValues(string clause, params object[] values)
		{
			int count = 0;
			return Regex.Replace(clause, "\\?", delegate(Match match)
			{
				string value = "";
				if (count < values.Length)
				{
					value = this.Adapter.Quote(values[count]);
					count++;
				}
				return value;
			});
		}
	   


		public T Where(string clause, object value)
		{
			return this.Where(clause, value);
		}

		public T Where(string clause, object value, object value2)
		{
			return this.Where(clause, new[] { value, value2 });
		}

		public T Where(string clause, object value, object value2, object value3)
		{
			return this.Where(clause, new[] { value, value2, value3 });
		}

		public T Where(string clause, params object[] values)
		{
			this.options.Conditions = new[] { clause, values }; 
			return (T)this;
		}

		public T Where(string clause, IDictionary<string, object> values)
		{
			this.options.Conditions = new[] { clause, values };
			return (T)this;
		}


		public T OrderBy(string orderBy)
		{
			this.options.OrderBy = orderBy;
		}

		public T Having(string having)
		{
			this.having += "HAVING " + having + " ";
			return (T)this;
		}

		public T GroupBy(string groupBy)
		{
			this.options.GroupBy = groupBy;
			return (T)this;
		}

		

		public T Limit(int limit)
		{
			this.limit = limit;
			return (T)this;
		}

		public T Limit(int limit, int offset)
		{
			this.offset = offset;
			return this.Limit(limit);
		}


		protected string BuildQuery()
		{
			switch (this.type)
			{
				case QueryType.Select:
					return this.BuildSelect();
				case QueryType.Insert:
					return this.BuildInsert();
				case QueryType.Update:
					return this.BuildUpdate();
				case QueryType.Delete:
					return this.BuildDelete();
			}
			return "";
		}

		protected string BuildFields(IEnumerable<string> fields, string prefix)
		{
			string	query = "",
					format = (prefix.Length > 0) ? "{0}.{1}, " : "{0}{1}, ";

			foreach (string field in fields)
				query +=  string.Format(format, prefix, field);

			return query.TrimEnd(", ".ToCharArray()) + " ";
		}

		protected string BuildSelect()
		{
			string prefix = (this.joins.Count > 0) ? this.TableAlias : "",
					query = "SELECT ",
					tableFormat = (prefix.Length > 0) ? "FROM  {0} as {1} " : "FROM {0}{1} ";

			if (this.IsDistinct)
				query += "DISTINCT ";

			query += (this.fields.Count > 0)  ? this.BuildFields(fields, prefix) : "* ";
			query += string.Format(tableFormat, this.Adapter.QuoteTableName(this.DatabaseEntity), prefix);
		
			if(!string.IsNullOrEmpty(this.whereClause))
				query += whereClause;

			if (!string.IsNullOrEmpty(this.orderBy))
				query += this.orderBy;

			if (!string.IsNullOrEmpty(this.groupBy))
				query += this.groupBy;

			if (!string.IsNullOrEmpty(this.having))
				query += this.having;

			this.Adapter.Limit(limit, offset, query);

			return query;
		}

		protected string BuildInsert()
		{
			string query = string.Format("INSERT INTO {0} ", 
				this.Adapter.QuoteTableName(this.DatabaseEntity));

			return query;
		}

		protected string BuildUpdate()
		{
			string query = string.Format("UPDATE {0} SET ", 
				this.Adapter.QuoteTableName(this.DatabaseEntity));

			return query;
		}

		protected string BuildDelete()
		{
			string query = string.Format("DELETE FROM {0} ", 
				this.Adapter.QuoteTableName(this.DatabaseEntity));

			return query;
		}

		

		public override string ToString()
		{
			return this.BuildQuery();
		}
	}
}
