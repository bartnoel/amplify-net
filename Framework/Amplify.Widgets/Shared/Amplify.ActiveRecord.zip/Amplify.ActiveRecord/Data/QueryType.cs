﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Amplify.ActiveRecord.Data
{
	public enum QueryType
	{
		Select,
		Update,
		Insert,
		Delete
	}
}
