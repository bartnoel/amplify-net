﻿

namespace Amplify.ActiveRecord.Data
{
	using System;
	using System.Collections.Generic;
	using System.Data;
	using System.Linq;
	using System.Text;


	public interface ICommandOptions
	{
		string CommandText { get;  }
		Scope Scope { get; } 
		CommandType CommandType { get; } 
		IEnumerable<IDataParameter> Parameters { get; }
	}
}
