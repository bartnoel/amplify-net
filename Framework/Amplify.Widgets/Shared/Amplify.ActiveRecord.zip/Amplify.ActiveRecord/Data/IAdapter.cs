﻿

namespace Amplify.ActiveRecord.Data
{
	using System;
	using System.Collections.Generic;
	using System.Data;
	using System.Text;

	public interface IAdapter
	{
		string ParameterPrefix { get; } 
		string Limit(int limit, int offset, string query);
		IDbConnection Connect();
		IDataParameter NewDataParameter(string columnName, object value);
		IDataParameter NewDataParameter(string columnName, object value, SqlDbType dbType);
		IDataParameter NewDataParameter(string columnName, object value, SqlDbType dbType, int limit);
		string Quote(object value);
		string QuoteTableName(string tableName);
		string QuoteColumnName(string columnName);
		void CreateDatabase(string databaseName);
		void DropDatabase(string databaseName);
		void RecreateDatabase(string databaseName);
		IEnumerable<string> Tables(string? name);
	}
}
