﻿//-----------------------------------------------------------------------
// <copyright file="Copyright.cs" author="Michael Herndon">
//     Copyright (c) Michael Herndon.  All rights reserved.
// </copyright>
//-----------------------------------------------------------------------


namespace Amplify.ActiveRecord.Data.Adapters
{
	using System;
	using System.Collections.Generic;
	using System.Data;
	using System.Data.SqlClient;
	using System.Text;

	public class SqlAdapter : AdapterBase 
	{
		private string connectionString;
		private string ParameterPrefix = "@";

		public SqlAdapter(string connectionString)
		{
			this.connectionString = connectionString;
		}

	

		public override string Limit(int limit, int offset, string query)
		{
			if (limit == -1)
				return query;
			if (limt > -1 && offset == -1)
			{
				if (query.Contains("DISTINCT"))
					return query.Replace("DISTINCT", limit.ToString().Wrap("DISTINCT TOP {0}"));
				else
					return query.Replace("SELECT", limit.ToString().Wrap("SELECT TOP {0}"));
			}
			else
			{
				
			}		  
		}

		public override System.Data.IDbConnection Connect()
		{
			return new SqlConnection(this.connectionString);
		}

		public override System.Data.IDataParameter NewDataParameter(string columnName, object value)
		{
			return new SqlParameter(this.ParameterPrefix + columnName, value);
		}

		public override System.Data.IDataParameter NewDataParameter(string columnName, object value, SqlDbType dbType)
		{
			SqlParameter param = new  SqlParameter(this.ParameterPrefix + columnName, dbType);
			param.Value = value;
			return param;
		}

		public override System.Data.IDataParameter NewDataParameter(string columnName, object value, SqlDbType dbType, int limit)
		{
			SqlParameter param = new SqlParameter(this.ParameterPrefix + columnName, dbType, limit);
			param.Value = value;
			return param;
		}
	}
}
