﻿

namespace Amplify.ActiveRecord.Data
{
	using System;
	using System.Collections;
	using System.Collections.Generic;
	using System.Data;
	using System.Text;
	using Amplify.ActiveRecord;
	using Amplify.Mixin.Ruby;

	public abstract class AdapterBase : IAdapter 
	{
		protected string QuotedFormat { get; set; }

		public AdapterBase()
		{
			this.QuotedFormat = "'{0}'";
		}

		public string Quote(object value)
		{
			return this.Quote(value, null);
		}

		public string Quote(object value)
		{
			if (value.IsNull())
				return "NULL";

		
		

			switch (value.GetType())
			{

				case "System.String":
				case "System.Byte[]":

					return this.Quote(value.ToString());
				case "DateTime":
					return Quote((DateTime)value);
			}
		}

		public virtual string Quote(string value)
		{
			return (value.IsNull()) ? "NULL" : value.Replace("'", "''");
		}

		public virtual string Quote(bool value)
		{
			if (value.IsNull())
				return "NULL";

			return (value) ? "'1'" : "'2'";
		}

		public virtual string Quote(DateTime value)
		{
			return  (value.IsNull()) ? "NULL" : value.ToString("Ymd H:M:S");
		}

		public virtual string QuoteColumnName(string columnName)
		{
			return columnName.Wrap("[{0}]");
		}

		public virtual string QuoteTableName(string tableName)
		{
			return tableName.Wrap("[{0}]");
		}
	


		


		#region IAdapter Members

		public abstract string Limit(int limit, int offset);

		public abstract string Limit(int limit, int offset, string query);

		public abstract IDbConnection Connect();

		public abstract IDataParameter NewDataParameter(string columnName, object value);

		public abstract IDataParameter NewDataParameter(string columnName, object value, SqlDbType dbType);

		public abstract IDataParameter NewDataParameter(string columnName, object value, SqlDbType dbType, int limit);

		public string QuoteTableName(string tableName)
		{
			return tableName.Wrap("[{0}]");
		}

		public string QuoteColumnName(string columnName)
		{
			return columnName.Wrap("[{0}]");
		}


		public IDataReader ExecuteSp(string storedProcedure)
		{
			return this.ExecuteSp(storedProcedure, null);
		}

		public IDataReader ExecuteSp(string storedProdcedure, IEnumerable<IDbDataParameter> parameters)
		{
			return this.Execute(new CommandOptions()
			{
				Scope = Scope.All,
				Parameters = parameters,
				CommandType = CommandType.StoredProcedure,
				CommandText = storedProdcedure
			});

		}

		public IDataReader SelectOne(string sql)
		{
			return Select(sql, Scope.First, null);
		}

		public IDataReader SelectOne(string sql, IEnumerable<IDbDataParameter> parameters)
		{
			return Select(sql, Scope.First, parameters);
		}

		public IDataReader SelectAll(string sql)
		{
			return Select(sql, Scope.All, null);
		}

		public IDataReader SelectAll(string sql, IEnumerable<IDbDataParameter> parameters)
		{
			return Select(sql, Scope.All, parameters);
		}

		protected IDataReader Select(string sql, Scope scope, IEnumerable<IDbDataParameter> parameters)
		{
			return Execute(new CommandOptions()
			{
				CommandText = sql,
				Scope = scope,
				CommandType = CommandType.Text,
				Parameters = parameters
			});
		}

		protected T ReadRow<T>(IDataReader dr)
		{
			Hashtable table = new Hashtable();
			for (int i = 0; i < dr.FieldCount; i++)
			{
				object value = dr[i];
				if (value == DBNull.Value)
					value = null;

				table.Add(dr.GetName(i), value);
			}
			return table;
		}

		protected IDataReader Execute(ICommandOptions query)
		{
			IDbConnection connection = Connect();
			try
			{
				query.
				connection.Open();
				CommandBehavior behavior = CommandBehavior.CloseConnection;
				if (scope == Scope.First)
					behavior = behavior | CommandBehavior.SingleRow;

				IDbCommand command = connection.CreateCommand();
				command.CommandType = type;
				command.CommandText = sql;

				if (parameters != null)
					parameters.Each(item => command.Parameters.Add(item));

				return command.ExecuteReader(behavior);
			}
			catch
			{
				connection.Close();
				throw;
			}
		}


		#endregion
	}
}
