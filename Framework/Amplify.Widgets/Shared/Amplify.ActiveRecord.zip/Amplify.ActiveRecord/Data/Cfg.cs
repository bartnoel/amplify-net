﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Amplify.ActiveRecord.Data
{
	public class Cfg
	{

		public static string DefaultConnectionString { get; set; }
 
		public static Adapters.IAdapter DefaultAdapter { get; set; }

	}
}
