﻿//-----------------------------------------------------------------------
// <copyright file="Copyright.cs" author="Michael Herndon">
//     Copyright (c) Company.  All rights reserved.
// </copyright>
//-----------------------------------------------------------------------

namespace Amplify.Models
{
	using System;
	using System.ComponentModel;
	using System.Collections.Generic;
	using System.Text;

	public class ModelList<T> : BindingList<T> 
		where T: Base<T>
	{

		public T First
		{
			get { return this[0]; }
		}


		public T Find(Predicate<T> match)
		{
			foreach (T item in this)
				if (match(item))
					return item;
			return null;
		}

		public ModelList<T> FindAll(Predicate<T> match)
		{
			ModelList<T> list = new ModelList<T>();
			foreach (T item in this)
				if (match(item))
					list.Add(item);
			return list;

		}

		internal sealed class FunctorComparer<T> : IComparer<T>
		{
			private Comparer<T> comparer;
			private Comparison<T> comparison;

			public FunctorComparer(Comparison<T> comparison)
			{
				this.comparer = Comparer<T>.Default;
				this.comparison = comparison;
			}

			public int Compare(T x, T y)
			{
				return this.comparison(x, y);
			}
		}


		public ModelList<T> Filter(Predicate<T> filter)
		{
			ModelList<T> list = new ModelList<T>();
			foreach (T item in this)
				if (filter(item))
					list.Add(item);
			return list;
		}

		public ModelList<T> Sort(Comparison<T> comparison)
		{
			IComparer<T> comparer = new FunctorComparer<T>(comparison);
			return Sort(comparer);
		}

		protected virtual ModelList<T> Sort(IComparer<T> comparer)
		{
			return Sort(0, this.Count, comparer);
		}

		protected virtual ModelList<T>  Sort(int index, int count, IComparer<T> comparer)
		{
			T[] temp = new T[this.Count];
			this.CopyTo(temp, 0);
			Array.Sort<T>(temp, index, count, comparer);
			return new ModelList<T>(temp);
		}

	}
}
