﻿//-----------------------------------------------------------------------
// <copyright file="Copyright.cs" author="Michael Herndon">
//     Copyright (c) Company.  All rights reserved.
// </copyright>
//-----------------------------------------------------------------------

namespace Amplify.ActiveRecord
{
	using System;
	using System.Collections.Generic;
	using System.ComponentModel;
	using System.Text;

	public class UnitOfWork : DecoratedObject, IUnitOfWork, INotifyPropertyChanged, INotifyPropertyChanging 
	{
		private bool isNew = true;
		private bool isModified = false;
		private bool isDeleted = false;
		
		public virtual bool IsNew
		{
			get { return this.isNew; }
		}

		public virtual bool IsModified
		{
			get { return this.isModified; }
		}

		public virtual bool IsValid
		{
			get { return true; }
		}

		public virtual bool IsDeleted
		{
			get { return this.isDeleted; }
		}

		public virtual bool IsSaveable
		{
			get { return (this.IsValid && this.IsModified); }
		}

		protected override void SetProperty(string propertyName, object value)
		{
			if(!Object.Equals(this.Get(propertyName), value))
			{
				this.NotifyPropertyChanging(propertyName);
				base.Set(propertyName, value);
				this.Validate(propertyName, value);
				this.NotifyPropertyChanged(propertyName);
			}
		}


		protected virtual void NotifyPropertyChanging(string propertyName)
		{
			PropertyChangingEventHandler eh = this.PropertyChanging;
			if (eh != null)
				eh(this, new PropertyChangingEventArgs(propertyName));
		}

		protected virtual void NotifyPropertyChanged(string propertyName) 
		{
			PropertyChangedEventHandler eh = this.PropertyChanged;
			if (eh != null)
				eh(this, new PropertyChangedEventArgs(propertyName));

			this.MarkModified();
		}

		protected virtual void Validate(string propertyName, object value)
		{

		}

		protected virtual void MarkModified() { this.isModified = true; }

		protected virtual void MarkNew() { 
			this.isNew = true;
			this.isModified = false;
		}

		protected virtual void MarkForDeletion() { this.isDeleted = true; }

		protected virtual void MarkNotDeleted() { this.isDeleted = false; }

		protected virtual void MarkOld() 
		{ 
			this.isModified = false;
			this.isNew = false; 
		}

		public virtual object Save()
		{
			if (this.IsDeleted)
				this.DeleteSelf();
			else {
				if (!this.IsSaveable)
					throw new InvalidOperationException("The save operation can not be performed");
		
				if (this.IsNew)
					this.Insert();
				else
					this.Update();

				this.MarkOld();
			}
			return this;
		}

		protected virtual void Update() 
		{
			throw new NotImplementedException();
		}

		protected virtual void Insert() 
		{
			throw new NotImplementedException();
		}

		protected virtual void DeleteSelf() 
		{
			throw new NotImplementedException();
		} 

		public virtual void Delete() 
		{
			this.MarkForDeletion();
			this.Save();
		}


		#region INotifyPropertyChanged Members

		public event PropertyChangedEventHandler PropertyChanged;

		#endregion

		#region INotifyPropertyChanging Members

		public event PropertyChangingEventHandler PropertyChanging;

		#endregion
	}
}
