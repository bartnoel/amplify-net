﻿//-----------------------------------------------------------------------
// <copyright file="Copyright.cs" author="Michael Herndon">
//     Copyright (c) Company.  All rights reserved.
// </copyright>
//-----------------------------------------------------------------------

namespace Amplify.Models
{
	using System;
	using System.Collections.Generic;
	using System.ComponentModel;
	using System.Data;
	using System.Text;

	public class DynamicTransactionalProvider
	{
		


		public enum Scope
		{
			All,
			First,
		}

		public T FindEvery<T>() where T: ModelList<T>
		{
		
		}

		public T FindInitial<T>() where T: Base<T> 
		{

		}

		public ModelList<T> FindByIds()
		{

		}

		public T Find<T>(string scope, IEnumerable<Sql> commands)
		{

		}

		public ModelList<T> Find<T>(IEnumerable<Sql> commands)
		{
			
		}

		protected abstract IDbConnection Connect();

		internal protected T Select<T>() where T:Base<T>
		{
			using (IDbConnection connection = Connect())
			{
				using (IDbCommand command = connection.CreateCommand())
				{
					command.CommandText = "";
					command.CommandType = CommandType.Text;
					T = Activator.CreateInstance<T>();

				}


			}
		}
	}
}
